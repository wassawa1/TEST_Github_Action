def add_val(a,b):
    return a+b

def sub_val(a,b):
    return a-b

def mul_val(a,b):
    return a*b